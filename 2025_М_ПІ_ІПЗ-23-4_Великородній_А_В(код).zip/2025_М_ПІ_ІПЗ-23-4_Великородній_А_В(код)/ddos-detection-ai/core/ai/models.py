import torch

from core.ai.utils import build_drqn, build_rnn_classifier, load_scaler

scaler = load_scaler()

rnn_classifier = build_rnn_classifier()

device = torch.device('cpu')

drqn = build_drqn()
drqn_hidden = drqn.init_hidden(1, device=device)