import os
import pickle
from typing import List, Optional

import pandas as pd
from sklearn.preprocessing import StandardScaler
import torch

from core.ai.rnn import Autoencoder, AeRnnClassifier
from core.ai.dqn import DRQN
from core.api.app.schemas import Sequence

REQUEST_TO_PD_KEY_MAP = {
    'flow_duration': 'Flow Duration',
    'total_fwd_packets': 'Total Fwd Packets',
    'total_bwd_packets': 'Total Backward Packets',
    'fwd_packet_length_total': 'Fwd Packets Length Total',
    'bwd_packet_length_total': 'Bwd Packets Length Total',
    'flow_packets_s': 'Flow Packets/s',
    'flow_iat_mean': 'Flow IAT Mean',
    'flow_iat_std': 'Flow IAT Std',
    'flow_iat_max': 'Flow IAT Max',
    'flow_iat_min': 'Flow IAT Min',
    'fwd_iat_total': 'Fwd IAT Total',
    'fwd_iat_mean': 'Fwd IAT Mean',
    'fwd_iat_std': 'Fwd IAT Std',
    'fwd_iat_max': 'Fwd IAT Max',
    'fwd_iat_min': 'Fwd IAT Min',
    'bwd_iat_total': 'Bwd IAT Total',
    'bwd_iat_mean': 'Bwd IAT Mean',
    'bwd_iat_std': 'Bwd IAT Std',
    'bwd_iat_max': 'Bwd IAT Max',
    'bwd_iat_min': 'Bwd IAT Min',
    'fwd_psh_flags': 'Fwd PSH Flags',
    'bwd_psh_flags': 'Bwd PSH Flags',
    'fwd_urg_flags': 'Fwd URG Flags',
    'bwd_urg_flags': 'Bwd URG Flags',
    'fwd_header_length': 'Fwd Header Length',
    'bwd_header_length': 'Bwd Header Length',
    'fwd_packet_s': 'Fwd Packets/s',
    'bwd_packet_s': 'Bwd Packets/s',
    'syn_flag_count': 'SYN Flag Count',
    'rst_flag_count': 'RST Flag Count',
    'ack_flag_count': 'ACK Flag Count',
    'ece_flag_count': 'ECE Flag Count',
    'down_up_ratio': 'Down/Up Ratio',
    'fwd_avg_bytes_bulk': 'Fwd Avg Bytes/Bulk',
    'fwd_avg_packets_bulk': 'Fwd Avg Packets/Bulk',
    'fwd_avg_bulk_rate': 'Fwd Avg Bulk Rate',
    'bwd_avg_bytes_bulk': 'Bwd Avg Bytes/Bulk',
    'bwd_avg_packets_bulk': 'Bwd Avg Packets/Bulk',
    'bwd_avg_bulk_rate': 'Bwd Avg Bulk Rate',
    'subflow_fwd_packets': 'Subflow Fwd Packets',
    'subflow_fwd_bytes': 'Subflow Fwd Bytes',
    'subflow_bwd_packets': 'Subflow Bwd Packets',
    'subflow_bwd_bytes': 'Subflow Bwd Bytes',
    'init_fwd_win_bytes': 'Init Fwd Win Bytes',
    'init_bwd_win_bytes': 'Init Bwd Win Bytes',
    'active_mean': 'Active Mean',
    'active_std': 'Active Std',
    'active_max': 'Active Max',
    'active_min': 'Active Min',
    'idle_mean': 'Idle Mean',
    'idle_std': 'Idle Std',
    'idle_max': 'Idle Max',
    'idle_min': 'Idle Min'
}


def parse_sequence(sequence: Sequence, scaler: StandardScaler):
    seq = []
    for request in sequence.requests:
        req_parsed = {REQUEST_TO_PD_KEY_MAP[key]:val for key, val in request.model_dump().items()}
        seq.append(req_parsed)
    seq = scaler.transform(pd.DataFrame(seq))
    return seq


def build_rnn_classifier() -> AeRnnClassifier:
    device = torch.device('cpu')
    latent_dim = 16
    input_dim = 53
    ae = Autoencoder(input_dim=input_dim, latent_dim=16).to(device)
    state = torch.load(
        os.environ.get("PATH_TO_AUTOENCODER_WEIGHTS", '/app/core/ai/autoencoder_pretrained.pth'),
        weights_only=True,
        map_location=device
    )
    ae.load_state_dict(state)
    pretrained_encoder = ae.encoder

    model = AeRnnClassifier(
        pretrained_encoder=pretrained_encoder,
        latent_dim=latent_dim,
        rnn_hidden_dim=64,
        num_classes=2
    ).to(device)

    state = torch.load(
        os.environ.get("PATH_TO_RNN_WEIGHTS", '/app/core/ai/classifier_rnn_attention.pth'),
        weights_only=True,
        map_location=device
    )
    model.load_state_dict(state)
    model.eval()
    return model

def load_scaler() -> StandardScaler:
    with open(os.environ.get("PATH_TO_SCALER", '/app/core/ai/scaler.pkl'), 'rb') as f:
        scaler: StandardScaler = pickle.load(f)
        return scaler

def rnn_inference(model: AeRnnClassifier, scaler: StandardScaler, sequence: Sequence) -> int:
    seq = parse_sequence(sequence, scaler)
    device = torch.device('cpu')
    seq = torch.tensor(seq, dtype=torch.float32, device=device).unsqueeze(0)
    padded = torch.nn.utils.rnn.pad_sequence(seq, batch_first=True)
    with torch.no_grad():
        length = torch.tensor(seq.size(1)).unsqueeze(0).type(torch.int64)
        logits = model(padded, length)
        preds = torch.argmax(logits, dim=1)
    return preds.squeeze(0).cpu().numpy().tolist()


def build_drqn() -> DRQN:
    hidden_dim = 128
    input_dim = 53
    action_dim = 2

    device = torch.device('cpu')
    model = DRQN(input_dim=input_dim, hidden_dim=hidden_dim, action_dim=action_dim).to(device)
    state = torch.load(
        os.environ.get("PATH_TO_DQN_WEIGHTS", '/app/core/ai/best_drqn.pt'),
        weights_only=True,
        map_location=device
    )
    model.load_state_dict(state)
    model.eval()
    return model


def drqn_infer(
    model: DRQN,
    scaler: StandardScaler,
    sequence: Sequence,
    hidden: Optional[torch.Tensor] = None
) -> int:
    seq = parse_sequence(sequence, scaler)
    device = torch.device('cpu')
    model.to(device)
    model.eval()
    seq_tensor = torch.tensor(seq, dtype=torch.float32, device=device).unsqueeze(0)
    if hidden is None:
        hidden = model.init_hidden(1, device=device)

    with torch.no_grad():
        q_all, hidden = model(seq_tensor, hidden)
        pred_idxs = q_all.argmax(dim=1)
        preds = pred_idxs.squeeze(0).cpu().numpy().tolist()

    return preds
