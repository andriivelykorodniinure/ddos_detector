import torch
from torch import nn
from torch.nn.utils.rnn import pack_padded_sequence, pad_packed_sequence

from core.ai.rnn.attention import Attention

class AeRnnClassifier(nn.Module):
    def __init__(self, pretrained_encoder: nn.Module, latent_dim: int,
                 rnn_hidden_dim: int, num_classes: int):
        super().__init__()
        self.encoder = pretrained_encoder
        self.rnn = nn.LSTM(input_size=latent_dim,
                           hidden_size=rnn_hidden_dim,
                           batch_first=True, num_layers=2, dropout=0.4)
        self.attention = Attention(rnn_hidden_dim).to("cpu")
        self.fc = nn.Sequential(
            nn.Dropout(0.45),
            nn.Linear(rnn_hidden_dim, num_classes)
        )

    def forward(self, x, lengths):
        b, t, f = x.size()
        x_flat = x.view(b*t, f)
        z_flat = self.encoder(x_flat)
        z = z_flat.view(b, t, -1)
        packed = pack_padded_sequence(z, lengths, batch_first=True, enforce_sorted=False)
        out, (h_n, c_n) = self.rnn(packed)
        lstm_out, _ = pad_packed_sequence(out, batch_first=True)
        context, attn_weights = self.attention(lstm_out, lengths)
        return self.fc(context)