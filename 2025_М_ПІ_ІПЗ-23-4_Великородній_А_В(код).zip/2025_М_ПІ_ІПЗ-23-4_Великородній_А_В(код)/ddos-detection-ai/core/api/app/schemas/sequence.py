from typing import List
from pydantic import BaseModel

from core.api.app.schemas.request import Request

class Sequence(BaseModel):
    requests: List[Request]
