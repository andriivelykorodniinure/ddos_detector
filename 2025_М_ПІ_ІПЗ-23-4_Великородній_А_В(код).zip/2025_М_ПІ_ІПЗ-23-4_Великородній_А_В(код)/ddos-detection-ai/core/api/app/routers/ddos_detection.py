from fastapi import APIRouter
from core.ai.models import drqn, drqn_hidden, rnn_classifier, scaler
from core.ai import drqn_infer, rnn_inference
from core.api.app.schemas import Sequence

router = APIRouter(
    prefix="/ddos-detection",
    tags=["ddos-detection"]
)

@router.post("/rnn")
async def detect_rnn(sequence: Sequence):
    return rnn_inference(rnn_classifier, scaler, sequence)

@router.post("/dqn")
async def detect_rnn(sequence: Sequence):
    return drqn_infer(drqn, scaler, sequence, drqn_hidden)