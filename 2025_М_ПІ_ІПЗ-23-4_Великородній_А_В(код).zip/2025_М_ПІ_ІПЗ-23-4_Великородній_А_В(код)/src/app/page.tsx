import RealtimeDashboardPage from "@/components/realtime-dashboard-page"

export default function Home() {
  return <RealtimeDashboardPage />
}
