import { NextResponse, type NextRequest } from "next/server"
import { getRecentLogIds, getLogsByIds } from "@/lib/redis-service"
import type { NetworkFlow } from "@/lib/types"

const LOG_PAGE_SIZE = 50

export async function GET(request: NextRequest) {
    try {
        const { searchParams } = new URL(request.url)
        const cursorParam = searchParams.get("cursor") // The timestamp of the last log from the previous page

        // The cursor is the score of the last item. We want items with scores *less than* the cursor.
        // The `(` prefix in the score range for zrevrangebyscore makes it exclusive.
        const maxTimestamp = cursorParam ? `(${cursorParam}` : "+inf"

        // Fetch one more than page size to determine if there are more pages
        const logIds = await getRecentLogIds(0, maxTimestamp, LOG_PAGE_SIZE + 1, 0, true)

        const hasMore = logIds.length > LOG_PAGE_SIZE
        const logsToReturnIds = hasMore ? logIds.slice(0, LOG_PAGE_SIZE) : logIds

        const logs: NetworkFlow[] = await getLogsByIds(logsToReturnIds)
        logs.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())

        // The next cursor will be the timestamp of the last item in the returned set
        const nextCursor = logs.length > 0 ? new Date(logs[logs.length - 1].timestamp).getTime() : null

        return NextResponse.json({
            logs,
            nextCursor,
            hasMore,
        })
    } catch (error) {
        console.error("[/api/get-logs] ERROR:", error)
        const errorMessage = error instanceof Error ? error.message : "Unknown server error"
        return NextResponse.json(
            {
                error: "Internal server error in get-logs API.",
                details: process.env.NODE_ENV === "development" ? errorMessage : undefined,
            },
            { status: 500 },
        )
    }
}
