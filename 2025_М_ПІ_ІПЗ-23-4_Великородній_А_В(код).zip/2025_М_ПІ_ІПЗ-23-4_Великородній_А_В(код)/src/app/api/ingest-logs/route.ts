import { NextResponse, type NextRequest } from "next/server"
import { getDetectionMethod, addProcessedLog, pruneOldLogIds, addBatchDdosStatus } from "@/lib/redis-service"
import type { NetworkFlow, IngestRequestBody } from "@/lib/types"
import { detectionMethodFunctions } from "@/lib/detection-methods"
import type { RawFlowData } from "@/lib/detection-methods/types"

export async function POST(request: NextRequest) {
  try {
    const { logs: rawNewFlowsData } = (await request.json()) as IngestRequestBody
    if (!rawNewFlowsData || !Array.isArray(rawNewFlowsData) || rawNewFlowsData.length === 0) {
      return NextResponse.json({ error: "No flow data provided or invalid format" }, { status: 400 })
    }

    const activeMethod = await getDetectionMethod()
    const detectionFn = detectionMethodFunctions[activeMethod]

    let isBatchDdos = false
    if (detectionFn && activeMethod !== "None") {
      isBatchDdos = await detectionFn(rawNewFlowsData as RawFlowData[])
    }

    await addBatchDdosStatus(isBatchDdos)

    const processedFlowsThisRequest: NetworkFlow[] = rawNewFlowsData.map((rawFlow) => ({
      ...(rawFlow as RawFlowData),
      id: crypto.randomUUID(),
      timestamp: new Date().toISOString(),
      label: isBatchDdos ? "SUSPICIOUS" : "NORMAL",
      markedBy: isBatchDdos ? activeMethod : undefined,
    }))

    for (const flow of processedFlowsThisRequest) {
      await addProcessedLog(flow)
    }

    pruneOldLogIds().catch((err) => {
      // Log error for background task, but don't fail the request
      console.error("Background task 'pruneOldLogIds' failed:", err)
    })

    return NextResponse.json({
      success: true,
      processedCount: processedFlowsThisRequest.length,
      batchMarkedDdos: isBatchDdos,
    })
  } catch (error) {
    console.error("Error ingesting flow data:", error)
    const errorMessage = error instanceof Error ? error.message : "Unknown server error"
    return NextResponse.json(
        { error: "Internal server error during flow ingestion", details: errorMessage },
        { status: 500 },
    )
  }
}
