import Redis from "ioredis"
import type { NetworkFlow, DetectionMethod } from "./types"
import {
  REDIS_LOG_PREFIX,
  REDIS_DETECTION_METHOD_KEY,
  REDIS_RECENT_LOG_IDS_KEY,
  LOG_TTL_SECONDS,
  REDIS_RECENT_BATCH_STATUS_KEY,
  MAX_RECENT_BATCHES_TRACKED,
} from "./redis-keys"

let redisClient: Redis | null = null

function getRedisClient(): Redis {
  if (redisClient) {
    return redisClient
  }
  const redisUrl = process.env.REDIS_URL
  if (!redisUrl) {
    // This console error is critical runtime feedback
    console.error("CRITICAL: REDIS_URL environment variable is NOT SET. Redis service cannot operate.")
    throw new Error("REDIS_URL environment variable is not set. Cannot initialize Redis client.")
  }
  redisClient = new Redis(redisUrl, {
    maxRetriesPerRequest: 3,
    lazyConnect: true,
    tls: redisUrl.startsWith("rediss://") ? {} : undefined,
    connectTimeout: 10000,
    retryStrategy(times) {
      if (times > 3) return null
      return Math.min(times * 50, 2000)
    },
  })
  redisClient.on("error", (err) => console.error("Redis Client Error:", err))
  redisClient.on("connect", () => console.log("Successfully connected to Redis."))
  return redisClient
}

export async function setDetectionMethod(method: DetectionMethod): Promise<void> {
  const client = getRedisClient()
  await client.set(REDIS_DETECTION_METHOD_KEY, method)
}

export async function getDetectionMethod(): Promise<DetectionMethod> {
  const client = getRedisClient()
  const method = (await client.get(REDIS_DETECTION_METHOD_KEY)) as DetectionMethod | null
  return method || "None"
}

export async function addProcessedLog(flow: NetworkFlow): Promise<void> {
  const client = getRedisClient()
  const logKey = `${REDIS_LOG_PREFIX}${flow.id}`
  const logTimestamp = new Date(flow.timestamp).getTime()
  const pipeline = client.pipeline()
  pipeline.setex(logKey, LOG_TTL_SECONDS, JSON.stringify(flow))
  pipeline.zadd(REDIS_RECENT_LOG_IDS_KEY, logTimestamp, flow.id)
  await pipeline.exec()
}

export async function getRecentLogIds(
    minTimestamp: number | string,
    maxTimestamp: number | string,
    limit: number,
    offset = 0,
    newestFirst = true,
): Promise<string[]> {
  const client = getRedisClient()
  if (newestFirst) {
    return client.zrevrangebyscore(
        REDIS_RECENT_LOG_IDS_KEY,
        maxTimestamp.toString(),
        minTimestamp.toString(),
        "LIMIT",
        offset,
        limit,
    )
  }
  return client.zrangebyscore(
      REDIS_RECENT_LOG_IDS_KEY,
      minTimestamp.toString(),
      maxTimestamp.toString(),
      "LIMIT",
      offset,
      limit,
  )
}

export async function getLogsByIds(ids: string[]): Promise<NetworkFlow[]> {
  const client = getRedisClient()
  if (ids.length === 0) return []
  const keys = ids.map((id) => `${REDIS_LOG_PREFIX}${id}`)
  const results = await client.mget(keys)
  return results
      .filter((res): res is string => res !== null)
      .map((res) => JSON.parse(res) as NetworkFlow)
      .filter((flow): flow is NetworkFlow => flow !== null && typeof flow === "object" && flow.id !== undefined)
}

export async function pruneOldLogIds(): Promise<void> {
  const client = getRedisClient()
  // Add a 60s buffer to TTL to ensure logs are not pruned before their ID might be needed from the sorted set
  const oldestTimestampToKeep = Date.now() - (LOG_TTL_SECONDS + 60) * 1000
  await client.zremrangebyscore(REDIS_RECENT_LOG_IDS_KEY, "-inf", oldestTimestampToKeep)
}

export async function addBatchDdosStatus(isDdosBatch: boolean): Promise<void> {
  const client = getRedisClient()
  const pipeline = client.pipeline()
  pipeline.lpush(REDIS_RECENT_BATCH_STATUS_KEY, isDdosBatch ? "1" : "0")
  pipeline.ltrim(REDIS_RECENT_BATCH_STATUS_KEY, 0, MAX_RECENT_BATCHES_TRACKED - 1)
  await pipeline.exec()
}

export async function getRecentBatchDdosStatuses(): Promise<boolean[]> {
  const client = getRedisClient()
  const results = await client.lrange(REDIS_RECENT_BATCH_STATUS_KEY, 0, -1)
  return results.map((status) => status === "1")
}
