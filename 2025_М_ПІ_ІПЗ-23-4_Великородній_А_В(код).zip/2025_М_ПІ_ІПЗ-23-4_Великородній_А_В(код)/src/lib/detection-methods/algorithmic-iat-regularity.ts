import type { DetectionFunction, RawFlowData } from "./types"

/**
 * Detects DDoS based on Inter-Arrival Time (IAT) Regularity.
 * If any flow in the batch shows a low Coefficient of Variation (Std/Mean) for IAT,
 * indicating highly regular packet timing, the entire batch is flagged.
 */
export const detectIatRegularity: DetectionFunction = (flowBatch: RawFlowData[]): boolean => {
    const cvThreshold = 0.1
    for (const flow of flowBatch) {
        if (flow["Flow IAT Mean"] === 0) {
            // A flow with zero mean IAT and zero std IAT (e.g. single packet or instantaneous packets) is highly regular.
            if (flow["Flow IAT Std"] === 0) return true
            continue
        }
        const iatCv = flow["Flow IAT Std"] / flow["Flow IAT Mean"]
        if (iatCv < cvThreshold) {
            return true
        }
    }
    return false
}
