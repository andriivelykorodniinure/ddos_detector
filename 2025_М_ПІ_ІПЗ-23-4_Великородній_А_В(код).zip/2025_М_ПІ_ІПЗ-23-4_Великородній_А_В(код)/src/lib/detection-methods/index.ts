import type { DetectionMethod } from "@/lib/types"
import type { DetectionFunction } from "./types"

import { detectSynRatio } from "./algorithmic-syn-ratio"
import { detectUnidirectionality } from "./algorithmic-unidirectionality"
import { detectIatRegularity } from "./algorithmic-iat-regularity"
import { detectLstmRnn } from "./ml-lstm-rnn"
import { detectDeepRl } from "./ml-deep-rl"

export const detectionMethodFunctions: Record<DetectionMethod, DetectionFunction | null> = {
  None: null,
  "AutoEncoder+LSTM": detectLstmRnn,
  "Deep RL": detectDeepRl,
  "Algorithmic - SYN Ratio": detectSynRatio,
  "Algorithmic - Unidirectionality": detectUnidirectionality,
  "Algorithmic - IAT Regularity": detectIatRegularity,
}
