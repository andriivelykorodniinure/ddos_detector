import type { DetectionFunction, RawFlowData } from "./types"
import type { MLServiceFlowSchema, MLServiceRequestBody } from "@/lib/types"

function transformFlowToMLSchema(flow: RawFlowData): MLServiceFlowSchema {
  // Ensure that values that should be float (e.g., 0.0) are formatted correctly
  // and values that should be integer (e.g., 0) are also correct.
  // Based on your "expected" snippet, many IAT and packet length totals are 0.0
  // and window sizes are 0.
  return {
    flow_duration: flow["Flow Duration"],
    total_fwd_packets: flow["Total Fwd Packets"],
    total_bwd_packets: flow["Total Backward Packets"],
    fwd_packet_length_total: Number.parseFloat(flow["Fwd Packets Length Total"].toFixed(1)), // Ensure float like 0.0
    bwd_packet_length_total: Number.parseFloat(flow["Bwd Packets Length Total"].toFixed(1)), // Ensure float like 0.0
    flow_packets_s: flow["Flow Packets/s"],
    flow_iat_mean: flow["Flow IAT Mean"],
    flow_iat_std: flow["Flow IAT Std"],
    flow_iat_max: flow["Flow IAT Max"],
    flow_iat_min: flow["Flow IAT Min"],
    fwd_iat_total: flow["Fwd IAT Total"],
    fwd_iat_mean: flow["Fwd IAT Mean"],
    fwd_iat_std: flow["Fwd IAT Std"],
    fwd_iat_max: flow["Fwd IAT Max"],
    fwd_iat_min: flow["Fwd IAT Min"],
    bwd_iat_total: flow["Bwd IAT Total"] || 0, // Default to 0 if not present or falsy
    bwd_iat_mean: flow["Bwd IAT Mean"] || 0,
    bwd_iat_std: flow["Bwd IAT Std"] || 0,
    bwd_iat_max: flow["Bwd IAT Max"] || 0,
    bwd_iat_min: flow["Bwd IAT Min"] || 0,
    fwd_psh_flags: flow["Fwd PSH Flags"],
    bwd_psh_flags: flow["Bwd PSH Flags"],
    fwd_urg_flags: flow["Fwd URG Flags"],
    bwd_urg_flags: flow["Bwd URG Flags"],
    fwd_header_length: flow["Fwd Header Length"],
    bwd_header_length: flow["Bwd Header Length"] || 0,
    fwd_packet_s: flow["Fwd Packets/s"],
    bwd_packet_s: flow["Bwd Packets/s"] || 0.0,
    syn_flag_count: flow["SYN Flag Count"],
    rst_flag_count: flow["RST Flag Count"],
    ack_flag_count: flow["ACK Flag Count"],
    ece_flag_count: flow["ECE Flag Count"],
    down_up_ratio: flow["Down/Up Ratio"] || 0.0,
    fwd_avg_bytes_bulk: flow["Fwd Avg Bytes/Bulk"] || 0,
    fwd_avg_packets_bulk: flow["Fwd Avg Packets/Bulk"] || 0,
    fwd_avg_bulk_rate: flow["Fwd Avg Bulk Rate"] || 0,
    bwd_avg_bytes_bulk: flow["Bwd Avg Bytes/Bulk"] || 0,
    bwd_avg_packets_bulk: flow["Bwd Avg Packets/Bulk"] || 0,
    bwd_avg_bulk_rate: flow["Bwd Avg Bulk Rate"] || 0,
    subflow_fwd_packets: flow["Subflow Fwd Packets"] || 0, // Expected as 0 in your example
    subflow_fwd_bytes: flow["Subflow Fwd Bytes"] || 0, // Expected as 0
    subflow_bwd_packets: flow["Subflow Bwd Packets"] || 0, // Expected as 0
    subflow_bwd_bytes: flow["Subflow Bwd Bytes"] || 0, // Expected as 0
    init_fwd_win_bytes: flow["Init Fwd Win Bytes"] || 0, // Expected as 0 in your example
    init_bwd_win_bytes: flow["Init Bwd Win Bytes"] || 0, // Expected as 0
    active_mean: flow["Active Mean"] || 0,
    active_std: flow["Active Std"] || 0,
    active_max: flow["Active Max"] || 0,
    active_min: flow["Active Min"] || 0,
    idle_mean: flow["Idle Mean"] || 0,
    idle_std: flow["Idle Std"] || 0,
    idle_max: flow["Idle Max"] || 0,
    idle_min: flow["Idle Min"] || 0,
  }
}

export const detectLstmRnn: DetectionFunction = async (flowBatch: RawFlowData[]): Promise<boolean> => {
  const mlServiceUrl = `${process.env.ML_SERVICE_URL}/rnn`
  if (!mlServiceUrl) {
    console.warn("ML_SERVICE_URL not configured for AutoEncoder+LSTM. Defaulting to 'not an attack'.")
    return false
  }

  if (!flowBatch || flowBatch.length === 0) {
    return false
  }

  const mlServicePayload: MLServiceFlowSchema[] = flowBatch.map(transformFlowToMLSchema)

  try {
    const response = await fetch(mlServiceUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ requests: mlServicePayload } as MLServiceRequestBody),
    })

    if (response.ok) {
      const resultText = await response.text()
      return resultText.trim() === "1"
    }
    console.error(`AutoEncoder+LSTM ML service call failed: ${response.status} ${await response.text()}`)
    return false
  } catch (error) {
    console.error("Error calling AutoEncoder+LSTM ML service:", error)
    return false
  }
}
