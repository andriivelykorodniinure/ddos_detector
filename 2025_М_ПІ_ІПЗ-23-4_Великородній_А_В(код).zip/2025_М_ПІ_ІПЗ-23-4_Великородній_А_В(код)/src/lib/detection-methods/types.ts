import type { NetworkFlow } from "@/lib/types"

/**
 * Represents the raw network flow data as received by the ingestion endpoint,
 * before system-added fields like id, label, timestamp, or markedBy.
 */
export type RawFlowData = Omit<NetworkFlow, "id" | "label" | "timestamp" | "markedBy">

/**
 * A function that processes a batch of raw network flows.
 * @param flowBatch An array of RawFlowData objects.
 * @returns A boolean or a Promise<boolean> indicating if the entire batch is considered part of a DDoS attack.
 *          `true` if DDoS, `false` otherwise.
 */
export type DetectionFunction = (flowBatch: RawFlowData[]) => Promise<boolean> | boolean
