import type { DetectionFunction, RawFlowData } from "./types"

/**
 * Detects DDoS based on Unidirectionality (low Down/Up Ratio).
 * If any flow in the batch has a Down/Up Ratio below the threshold,
 * (and has forward packets), the entire batch is flagged.
 */
export const detectUnidirectionality: DetectionFunction = (flowBatch: RawFlowData[]): boolean => {
    const threshold = 0.05 // Bwd Packets / Fwd Packets
    for (const flow of flowBatch) {
        if (flow["Total Fwd Packets"] === 0) continue
        if (flow["Down/Up Ratio"] < threshold) {
            return true
        }
    }
    return false
}
