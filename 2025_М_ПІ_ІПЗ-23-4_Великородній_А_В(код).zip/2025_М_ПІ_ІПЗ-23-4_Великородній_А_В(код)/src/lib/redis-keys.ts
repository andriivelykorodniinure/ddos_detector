export const REDIS_LOG_PREFIX = "log:"
export const REDIS_DETECTION_METHOD_KEY = "current_detection_method"
export const REDIS_RECENT_LOG_IDS_KEY = "recent_log_ids_sorted_set"
/** Stores '1' for a DDoS batch, '0' otherwise, for the last N batches. */
export const REDIS_RECENT_BATCH_STATUS_KEY = "recent_batch_statuses"

export const LOG_TTL_SECONDS = 600 // Store individual logs for 10 minutes
export const MAX_RECENT_BATCHES_TRACKED = 20
