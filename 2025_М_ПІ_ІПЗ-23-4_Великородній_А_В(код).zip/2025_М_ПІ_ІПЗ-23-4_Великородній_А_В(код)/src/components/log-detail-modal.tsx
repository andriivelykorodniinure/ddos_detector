"use client"

import { Badge } from "@/components/ui/badge"

import type React from "react"

import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import type { NetworkFlow } from "@/lib/types"
import { ScrollArea } from "@/components/ui/scroll-area"

interface LogDetailModalProps {
  log: NetworkFlow | null
  isOpen: boolean
  onClose: () => void
}

const DetailItem = ({ label, value }: { label: string; value: React.ReactNode }) => (
    <div>
      <span className="text-muted-foreground">{label}:</span> <span className="font-medium">{value}</span>
    </div>
)

export default function LogDetailModal({ log, isOpen, onClose }: LogDetailModalProps) {
  if (!log) return null

  const formatTimestamp = (isoString: string) => new Date(isoString).toLocaleString()
  const formatNumber = (num: number) => (Number.isInteger(num) ? num : num.toFixed(4))

  const getSuspiciousLabel = (log: NetworkFlow) => {
    if (log.label !== "SUSPICIOUS") return "NORMAL"
    return `SUSPICIOUS (${log.markedBy || "Unknown"})`
  }

  return (
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="sm:max-w-[600px] md:max-w-[800px] lg:max-w-[1000px]">
          <DialogHeader>
            <DialogTitle>Flow Details - ID: {log.id}</DialogTitle>
            <DialogDescription>
              {log.sourceIp} → {log.destinationIp} at {formatTimestamp(log.timestamp)}
            </DialogDescription>
          </DialogHeader>
          <ScrollArea className="max-h-[70vh] pr-4">
            <div className="space-y-6 py-4">
              {/* Basic Info */}
              <div className="space-y-2">
                <h4 className="font-semibold text-lg">Flow Summary</h4>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-x-4 gap-y-2 text-sm">
                  <DetailItem
                      label="Label"
                      value={
                        <Badge variant={log.label === "SUSPICIOUS" ? "destructive" : "secondary"}>
                          {getSuspiciousLabel(log)}
                        </Badge>
                      }
                  />
                  <DetailItem label="Flow Duration" value={`${formatNumber(log["Flow Duration"] / 1000)} ms`} />
                  <DetailItem label="Total Fwd Pkts" value={log["Total Fwd Packets"]} />
                  <DetailItem label="Total Bwd Pkts" value={log["Total Backward Packets"]} />
                  <DetailItem label="Total Fwd Bytes" value={log["Fwd Packets Length Total"]} />
                  <DetailItem label="Total Bwd Bytes" value={log["Bwd Packets Length Total"]} />
                  <DetailItem label="Flow Pkts/s" value={formatNumber(log["Flow Packets/s"])} />
                  <DetailItem label="Fwd Pkts/s" value={formatNumber(log["Fwd Packets/s"])} />
                  <DetailItem label="Bwd Pkts/s" value={formatNumber(log["Bwd Packets/s"])} />
                </div>
              </div>

              {/* IAT Stats */}
              <div className="space-y-2">
                <h4 className="font-semibold text-lg">Inter-Arrival Time (IAT) Stats</h4>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-x-4 gap-y-2 text-sm">
                  <DetailItem label="Flow IAT Mean" value={formatNumber(log["Flow IAT Mean"])} />
                  <DetailItem label="Flow IAT Std" value={formatNumber(log["Flow IAT Std"])} />
                  <DetailItem label="Flow IAT Max" value={formatNumber(log["Flow IAT Max"])} />
                  <DetailItem label="Flow IAT Min" value={formatNumber(log["Flow IAT Min"])} />
                  <DetailItem label="Fwd IAT Mean" value={formatNumber(log["Fwd IAT Mean"])} />
                  <DetailItem label="Fwd IAT Std" value={formatNumber(log["Fwd IAT Std"])} />
                  <DetailItem label="Fwd IAT Max" value={formatNumber(log["Fwd IAT Max"])} />
                  <DetailItem label="Fwd IAT Min" value={formatNumber(log["Fwd IAT Min"])} />
                </div>
              </div>

              {/* Header & Flag Stats */}
              <div className="space-y-2">
                <h4 className="font-semibold text-lg">Header & Flag Stats</h4>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-x-4 gap-y-2 text-sm">
                  <DetailItem label="Fwd Header Len" value={log["Fwd Header Length"]} />
                  <DetailItem label="Bwd Header Len" value={log["Bwd Header Length"]} />
                  <DetailItem label="Init Fwd Win Bytes" value={log["Init Fwd Win Bytes"]} />
                  <DetailItem label="Init Bwd Win Bytes" value={log["Init Bwd Win Bytes"]} />
                  <DetailItem label="SYN Flag Count" value={log["SYN Flag Count"]} />
                  <DetailItem label="ACK Flag Count" value={log["ACK Flag Count"]} />
                  <DetailItem label="RST Flag Count" value={log["RST Flag Count"]} />
                  <DetailItem label="ECE Flag Count" value={log["ECE Flag Count"]} />
                </div>
              </div>

              {/* Full Data */}
              <div>
                <h4 className="font-semibold text-lg mb-2">Full Flow Data (JSON)</h4>
                <pre className="bg-muted p-3 rounded-md text-xs overflow-x-auto">{JSON.stringify(log, null, 2)}</pre>
              </div>
            </div>
          </ScrollArea>
          <DialogFooter>
            <Button onClick={onClose}>Close</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
  )
}
