"use client"

import type React from "react"

import { useState, useEffect, useMemo, useCallback, useRef } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input" // Added for file input styling
import { Progress } from "@/components/ui/progress" // Added for progress bar
import { LineChart, Line, XAxis, YAxis, CartesianGrid, ResponsiveContainer } from "recharts"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"
import {
  ShieldAlert,
  ShieldCheck,
  BarChart3,
  AlertTriangle,
  Server,
  Network,
  UploadCloud,
  Info,
  Loader2,
  Play,
  Pause,
  Send,
} from "lucide-react"
import type { NetworkFlow, DashboardStatusResponse, DetectionMethod, RawFlowData } from "@/lib/types"
import { DETECTION_METHODS } from "@/lib/types"
import LogDetailModal from "./log-detail-modal"
import { ScrollArea } from "@/components/ui/scroll-area"
import { useToast } from "@/hooks/use-toast"

const POLLING_INTERVAL = 5000
const MAX_LOGS_TO_RETURN_UI = 50
const CSV_BATCH_SIZE = 20
const CSV_BATCH_OVERLAP = 10
const CSV_AUTO_SEND_INTERVAL = 10000 // 10 seconds

// Helper to generate sample flow data (existing function)
const generateFlowData = (isAttack: boolean): Omit<NetworkFlow, "id" | "label" | "timestamp" | "markedBy"> => {
  // ... (implementation from previous step, ensure it aligns with RawFlowData structure)
  // For brevity, I'll assume this function is correctly defined as before
  // and provides all necessary fields for RawFlowData.
  // Important: It should return an object compatible with the expanded RawFlowData.
  // This might mean adding default values for the new optional fields in NetworkFlow.
  const fwdPackets = isAttack ? Math.floor(Math.random() * 20) + 10 : Math.floor(Math.random() * 5) + 2
  const bwdPackets = isAttack ? Math.floor(Math.random() * 2) : Math.floor(Math.random() * 5) + 2
  const duration = isAttack ? Math.floor(Math.random() * 10000) + 500 : Math.floor(Math.random() * 500000) + 100000
  const baseFlow: RawFlowData = {
    sourceIp: `10.0.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`,
    destinationIp: `192.168.1.${Math.floor(Math.random() * 10) + 1}`,
    "Flow Duration": duration,
    "Total Fwd Packets": fwdPackets,
    "Total Backward Packets": bwdPackets,
    "Fwd Packets Length Total": fwdPackets * (isAttack ? 60 : 400),
    "Bwd Packets Length Total": bwdPackets * (isAttack ? 0 : 300),
    "Down/Up Ratio": bwdPackets > 0 && fwdPackets > 0 ? bwdPackets / fwdPackets : 0,
    "Flow Packets/s": (fwdPackets + bwdPackets) / (duration / 1_000_000 || 1),
    "Fwd Packets/s": fwdPackets / (duration / 1_000_000 || 1),
    "Bwd Packets/s": bwdPackets / (duration / 1_000_000 || 1),
    "Flow IAT Mean": isAttack ? 50 : 50000,
    "Flow IAT Std": isAttack ? 20 : 20000,
    "Flow IAT Max": isAttack ? 100 : 100000,
    "Flow IAT Min": isAttack ? 10 : 1000,
    "Fwd IAT Total": duration,
    "Fwd IAT Mean": fwdPackets > 0 ? duration / fwdPackets : 0,
    "Fwd IAT Std": isAttack ? 50 : 15000,
    "Fwd IAT Max": isAttack ? 150 : 80000,
    "Fwd IAT Min": isAttack ? 5 : 500,
    "Bwd IAT Total": bwdPackets > 1 ? duration * 0.8 : 0,
    "Bwd IAT Mean": bwdPackets > 1 ? (duration * 0.8) / bwdPackets : 0,
    "Bwd IAT Std": 0,
    "Bwd IAT Max": 0,
    "Bwd IAT Min": 0,
    "Fwd Header Length": fwdPackets * 20, // Assuming 20 bytes per header
    "Bwd Header Length": bwdPackets * 20,
    "Fwd PSH Flags": 0,
    "Bwd PSH Flags": 0,
    "Fwd URG Flags": 0,
    "Bwd URG Flags": 0,
    "SYN Flag Count": isAttack ? 1 : 1,
    "RST Flag Count": 0,
    "ACK Flag Count": isAttack ? 0 : fwdPackets + bwdPackets - 1,
    "ECE Flag Count": 0,
    "Init Fwd Win Bytes": isAttack ? 1024 : 8192,
    "Init Bwd Win Bytes": isAttack ? 0 : 8192,
    "Active Mean": 0,
    "Active Std": 0,
    "Active Max": 0,
    "Active Min": 0,
    "Idle Mean": 0,
    "Idle Std": 0,
    "Idle Max": 0,
    "Idle Min": 0,
    "Fwd Avg Bytes/Bulk": 0,
    "Fwd Avg Packets/Bulk": 0,
    "Fwd Avg Bulk Rate": 0,
    "Bwd Avg Bytes/Bulk": 0,
    "Bwd Avg Packets/Bulk": 0,
    "Bwd Avg Bulk Rate": 0,
    "Subflow Fwd Packets": fwdPackets,
    "Subflow Fwd Bytes": fwdPackets * (isAttack ? 60 : 400),
    "Subflow Bwd Packets": bwdPackets,
    "Subflow Bwd Bytes": bwdPackets * (isAttack ? 0 : 300),
    // Add defaults for new optional fields from CSV if generateFlowData is to be complete
    "Src Port": Math.floor(Math.random() * 60000) + 1024,
    "Dst Port": isAttack ? 80 : Math.floor(Math.random() * 60000) + 1024,
    Protocol: 6, // TCP
  }
  return baseFlow
}

// CSV Header to NetworkFlow key mapping
const csvHeaderMapping: Record<string, keyof RawFlowData> = {
  "Flow ID": "Flow ID", // Will be omitted for MLFeatures if not needed
  "Src IP": "sourceIp",
  "Src Port": "Src Port",
  "Dst IP": "destinationIp",
  "Dst Port": "Dst Port",
  Protocol: "Protocol",
  // "Timestamp" from CSV is ignored, system generates its own
  "Flow Duration": "Flow Duration",
  "Total Fwd Packet": "Total Fwd Packets",
  "Total Bwd packets": "Total Backward Packets",
  "Total Length of Fwd Packet": "Fwd Packets Length Total",
  "Total Length of Bwd Packet": "Bwd Packets Length Total",
  "Fwd Packet Length Max": "Fwd Packet Length Max",
  "Fwd Packet Length Min": "Fwd Packet Length Min",
  "Fwd Packet Length Mean": "Fwd Packet Length Mean",
  "Fwd Packet Length Std": "Fwd Packet Length Std",
  "Bwd Packet Length Max": "Bwd Packet Length Max",
  "Bwd Packet Length Min": "Bwd Packet Length Min",
  "Bwd Packet Length Mean": "Bwd Packet Length Mean",
  "Bwd Packet Length Std": "Bwd Packet Length Std",
  "Flow Bytes/s": "Flow Bytes/s",
  "Flow Packets/s": "Flow Packets/s",
  "Flow IAT Mean": "Flow IAT Mean",
  "Flow IAT Std": "Flow IAT Std",
  "Flow IAT Max": "Flow IAT Max",
  "Flow IAT Min": "Flow IAT Min",
  "Fwd IAT Total": "Fwd IAT Total",
  "Fwd IAT Mean": "Fwd IAT Mean",
  "Fwd IAT Std": "Fwd IAT Std",
  "Fwd IAT Max": "Fwd IAT Max",
  "Fwd IAT Min": "Fwd IAT Min",
  "Bwd IAT Total": "Bwd IAT Total",
  "Bwd IAT Mean": "Bwd IAT Mean",
  "Bwd IAT Std": "Bwd IAT Std",
  "Bwd IAT Max": "Bwd IAT Max",
  "Bwd IAT Min": "Bwd IAT Min",
  "Fwd PSH Flags": "Fwd PSH Flags",
  "Bwd PSH Flags": "Bwd PSH Flags",
  "Fwd URG Flags": "Fwd URG Flags",
  "Bwd URG Flags": "Bwd URG Flags",
  "Fwd Header Length": "Fwd Header Length",
  "Bwd Header Length": "Bwd Header Length",
  "Fwd Packets/s": "Fwd Packets/s",
  "Bwd Packets/s": "Bwd Packets/s",
  "Packet Length Min": "Packet Length Min",
  "Packet Length Max": "Packet Length Max",
  "Packet Length Mean": "Packet Length Mean",
  "Packet Length Std": "Packet Length Std",
  "Packet Length Variance": "Packet Length Variance",
  "FIN Flag Count": "FIN Flag Count",
  "SYN Flag Count": "SYN Flag Count",
  "RST Flag Count": "RST Flag Count",
  "PSH Flag Count": "PSH Flag Count",
  "ACK Flag Count": "ACK Flag Count",
  "URG Flag Count": "URG Flag Count",
  "CWR Flag Count": "CWR Flag Count",
  "ECE Flag Count": "ECE Flag Count",
  "Down/Up Ratio": "Down/Up Ratio",
  "Average Packet Size": "Average Packet Size",
  "Fwd Segment Size Avg": "Fwd Segment Size Avg",
  "Bwd Segment Size Avg": "Bwd Segment Size Avg",
  "Fwd Bytes/Bulk Avg": "Fwd Avg Bytes/Bulk",
  "Fwd Packet/Bulk Avg": "Fwd Avg Packets/Bulk",
  "Fwd Bulk Rate Avg": "Fwd Avg Bulk Rate",
  "Bwd Bytes/Bulk Avg": "Bwd Avg Bytes/Bulk",
  "Bwd Packet/Bulk Avg": "Bwd Avg Packets/Bulk",
  "Bwd Bulk Rate Avg": "Bwd Avg Bulk Rate",
  "Subflow Fwd Packets": "Subflow Fwd Packets",
  "Subflow Fwd Bytes": "Subflow Fwd Bytes",
  "Subflow Bwd Packets": "Subflow Bwd Packets",
  "Subflow Bwd Bytes": "Subflow Bwd Bytes",
  "FWD Init Win Bytes": "Init Fwd Win Bytes",
  "Bwd Init Win Bytes": "Init Bwd Win Bytes",
  "Fwd Act Data Pkts": "Fwd Act Data Pkts",
  "Fwd Seg Size Min": "Fwd Seg Size Min",
  "Active Mean": "Active Mean",
  "Active Std": "Active Std",
  "Active Max": "Active Max",
  "Active Min": "Active Min",
  "Idle Mean": "Idle Mean",
  "Idle Std": "Idle Std",
  "Idle Max": "Idle Max",
  "Idle Min": "Idle Min",
  // "Label" from CSV is ignored
}

export default function RealtimeDashboardPage() {
  const [dashboardData, setDashboardData] = useState<DashboardStatusResponse | null>(null)
  const [allLogs, setAllLogs] = useState<NetworkFlow[]>([])
  const [logCursor, setLogCursor] = useState<number | null>(null)
  const [hasMoreLogs, setHasMoreLogs] = useState(true)
  const [isFetchingMore, setIsFetchingMore] = useState(false)
  const [isLoading, setIsLoading] = useState<boolean>(true)
  const [isSendingLogs, setIsSendingLogs] = useState<boolean>(false) // For sample logs
  const [selectedLog, setSelectedLog] = useState<NetworkFlow | null>(null)
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false)

  // CSV Processing State
  const [parsedCsvData, setParsedCsvData] = useState<RawFlowData[]>([])
  const [csvFileName, setCsvFileName] = useState<string | null>(null)
  const [csvCurrentIndex, setCsvCurrentIndex] = useState<number>(0)
  const [isCsvProcessing, setIsCsvProcessing] = useState<boolean>(false) // For batch sending from CSV
  const [isCsvAutoSending, setIsCsvAutoSending] = useState<boolean>(false)
  const csvAutoSendIntervalRef = useRef<NodeJS.Timeout | null>(null)

  const { toast } = useToast()
  const fileInputRef = useRef<HTMLInputElement>(null)

  const loaderRef = useRef<HTMLDivElement>(null)
  const activeDetectionMethod = dashboardData?.activeDetectionMethod || "None"

  const fetchDashboardStatus = useCallback(async (isInitialLoad = false) => {
    // ... (implementation from previous step, ensure it's stable)
    if (document.hidden && !isInitialLoad) return
    if (isInitialLoad) setIsLoading(true)
    try {
      const response = await fetch(`/api/dashboard-status`)
      if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`)
      const data: DashboardStatusResponse = await response.json()
      setDashboardData(data)

      if (isInitialLoad) {
        setAllLogs(data.logs)
        if (data.logs.length > 0 && data.logs.length >= MAX_LOGS_TO_RETURN_UI) {
          setLogCursor(new Date(data.logs[data.logs.length - 1].timestamp).getTime())
          setHasMoreLogs(true)
        } else {
          setHasMoreLogs(false)
          setLogCursor(null)
        }
      } else {
        setAllLogs((prevAllLogs) => {
          const existingLogIds = new Set(prevAllLogs.map((l) => l.id))
          const newLogs = data.logs.filter((l) => !existingLogIds.has(l.id))
          if (newLogs.length > 0) {
            return [...newLogs, ...prevAllLogs].sort(
                (a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime(),
            )
          }
          return prevAllLogs
        })
      }
    } catch (error) {
      console.error("Failed to fetch dashboard status:", error)
    } finally {
      if (isInitialLoad) setIsLoading(false)
    }
  }, [])

  // ... (loadMoreLogs, useEffect for IntersectionObserver, useEffect for polling - from previous step)
  const loadMoreLogs = useCallback(async () => {
    if (isFetchingMore || !hasMoreLogs || !logCursor) return
    setIsFetchingMore(true)
    try {
      const response = await fetch(`/api/get-logs?cursor=${logCursor}`)
      const data = await response.json()
      setAllLogs((prev) => [...prev, ...data.logs])
      setLogCursor(data.nextCursor)
      setHasMoreLogs(data.hasMore)
    } catch (error) {
      console.error("Failed to fetch more logs:", error)
    } finally {
      setIsFetchingMore(false)
    }
  }, [isFetchingMore, hasMoreLogs, logCursor])

  useEffect(() => {
    const observer = new IntersectionObserver(
        (entries) => {
          if (entries[0].isIntersecting) {
            loadMoreLogs()
          }
        },
        { threshold: 1.0 },
    )
    const currentLoader = loaderRef.current
    if (currentLoader) observer.observe(currentLoader)
    return () => {
      if (currentLoader) observer.unobserve(currentLoader)
    }
  }, [loadMoreLogs])

  useEffect(() => {
    fetchDashboardStatus(true)
    const intervalId = setInterval(() => fetchDashboardStatus(false), POLLING_INTERVAL)
    return () => clearInterval(intervalId)
  }, [fetchDashboardStatus])

  const handleMethodChange = async (method: DetectionMethod) => {
    // ... (implementation from previous step)
    setIsLoading(true)
    try {
      await fetch(`/api/set-detection-method`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ method }),
      })
      await fetchDashboardStatus(true)
    } catch (error) {
      console.error("Failed to set detection method:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const formatTimestamp = (isoString: string) =>
      new Date(isoString).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false })

  const handleSendSampleLogs = async () => {
    // ... (implementation from previous step)
    setIsSendingLogs(true)
    const sampleLogs = Array.from({ length: 20 + Math.floor(Math.random() * 30) }, () =>
        generateFlowData(Math.random() < 0.3),
    )
    try {
      await fetch(`/api/ingest-logs`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ logs: sampleLogs }),
      })
      toast({ title: "Sample logs sent", description: `${sampleLogs.length} flows ingested.` })
      setTimeout(() => fetchDashboardStatus(false), 750)
    } catch (error) {
      console.error("Failed to send sample logs:", error)
      toast({ title: "Error sending sample logs", variant: "destructive" })
    } finally {
      setIsSendingLogs(false)
    }
  }

  const handleLogRowClick = (log: NetworkFlow) => {
    setSelectedLog(log)
    setIsModalOpen(true)
  }

  // CSV Processing Logic
  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      setCsvFileName(file.name)
      setParsedCsvData([])
      setCsvCurrentIndex(0)
      setIsCsvAutoSending(false)
      if (csvAutoSendIntervalRef.current) {
        clearInterval(csvAutoSendIntervalRef.current)
        csvAutoSendIntervalRef.current = null
      }

      const reader = new FileReader()
      reader.onload = (e) => {
        const text = e.target?.result as string
        try {
          const { data, errors } = parseCsvToRawFlowData(text)
          if (errors.length > 0) {
            toast({
              title: "CSV Parsing Errors",
              description: `Found ${errors.length} errors. First error: ${errors[0]}. Check console for details.`,
              variant: "destructive",
            })
            console.error("CSV Parsing Errors:", errors)
          }
          if (data.length === 0 && errors.length > 0 && !text.includes(",")) {
            toast({
              title: "CSV Parsing Failed",
              description: "No data parsed. Is this a valid CSV file with the expected headers?",
              variant: "destructive",
            })
            setCsvFileName(null)
            return
          }
          setParsedCsvData(data)
          toast({ title: "CSV Loaded", description: `${data.length} records parsed from ${file.name}.` })
        } catch (error) {
          toast({ title: "Failed to parse CSV", description: String(error), variant: "destructive" })
          setCsvFileName(null)
        }
      }
      reader.readAsText(file)
    }
    // Reset file input to allow re-uploading the same file
    if (fileInputRef.current) {
      fileInputRef.current.value = ""
    }
  }

  const parseCsvToRawFlowData = (csvText: string): { data: RawFlowData[]; errors: string[] } => {
    const lines = csvText.split(/\r\n|\n/).filter((line) => line.trim() !== "")
    if (lines.length < 2) return { data: [], errors: ["CSV has no data lines or only a header."] }

    const headers = lines[0].split(",").map((h) => h.trim())
    const numericKeys: (keyof RawFlowData)[] = Object.entries(csvHeaderMapping)
        .filter(([_, v]) => {
          // A bit of a heuristic: if not 'sourceIp', 'destinationIp', or 'Flow ID', assume numeric potential
          // This should ideally be more robust, perhaps by checking the target type in NetworkFlow
          return !["sourceIp", "destinationIp", "Flow ID"].includes(v as string)
        })
        .map(([_, v]) => v)

    const dataRows = lines.slice(1)
    const parsedData: RawFlowData[] = []
    const errors: string[] = []

    dataRows.forEach((line, rowIndex) => {
      const values = line.split(",")
      if (values.length !== headers.length) {
        errors.push(`Row ${rowIndex + 1}: Expected ${headers.length} columns, found ${values.length}. Skipping.`)
        return
      }

      const flowObject: Partial<RawFlowData> = {}
      let hasErrorInRow = false
      headers.forEach((header, colIndex) => {
        const rawValue = values[colIndex]?.trim()
        const targetKey = csvHeaderMapping[header]

        if (targetKey) {
          if (
              numericKeys.includes(targetKey) &&
              targetKey !== "sourceIp" &&
              targetKey !== "destinationIp" &&
              targetKey !== "Flow ID"
          ) {
            const numValue = Number.parseFloat(rawValue)
            if (isNaN(numValue)) {
              // errors.push(`Row ${rowIndex + 1}, Column "${header}": Invalid number "${rawValue}". Using 0.`);
              // (flowObject as any)[targetKey] = 0; // Default to 0 for unparseable numbers
              // For this demo, we will skip the row if any numeric field is not a number
              if (!hasErrorInRow)
                errors.push(`Row ${rowIndex + 1}, Column "${header}": Invalid number "${rawValue}". Skipping row.`)
              hasErrorInRow = true
            } else {
              ;(flowObject as any)[targetKey] = numValue
            }
          } else {
            ;(flowObject as any)[targetKey] = rawValue
          }
        }
      })
      if (!hasErrorInRow) {
        // Basic validation: ensure essential fields for RawFlowData are present
        // This is a simplified check; ideally, use a validation library like Zod
        if (flowObject.sourceIp && flowObject.destinationIp && typeof flowObject["Flow Duration"] === "number") {
          parsedData.push(flowObject as RawFlowData)
        } else {
          errors.push(`Row ${rowIndex + 1}: Missing essential fields after mapping. Skipping.`)
        }
      }
    })
    return { data: parsedData, errors }
  }

  const sendCsvBatch = async () => {
    if (csvCurrentIndex >= parsedCsvData.length) {
      toast({ title: "CSV Processing Complete", description: "All lines have been sent." })
      setIsCsvAutoSending(false)
      return
    }

    setIsCsvProcessing(true)
    const batch = parsedCsvData.slice(csvCurrentIndex, csvCurrentIndex + CSV_BATCH_SIZE)
    if (batch.length === 0) {
      setIsCsvProcessing(false)
      return
    }

    try {
      const response = await fetch(`/api/ingest-logs`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ logs: batch }),
      })
      if (!response.ok) throw new Error(`API Error: ${response.status}`)

      const result = await response.json()
      toast({
        title: `Batch Sent (Lines ${csvCurrentIndex + 1}-${csvCurrentIndex + batch.length})`,
        description: `${batch.length} flows ingested. Batch marked DDoS: ${result.batchMarkedDdos}.`,
      })
      setCsvCurrentIndex((prev) => prev + CSV_BATCH_OVERLAP)
      setTimeout(() => fetchDashboardStatus(false), 500) // Refresh dashboard data
    } catch (error) {
      console.error("Failed to send CSV batch:", error)
      toast({ title: "Error Sending CSV Batch", description: String(error), variant: "destructive" })
      setIsCsvAutoSending(false) // Stop auto-sending on error
    } finally {
      setIsCsvProcessing(false)
    }
  }

  useEffect(() => {
    if (isCsvAutoSending && parsedCsvData.length > 0 && csvCurrentIndex < parsedCsvData.length) {
      if (csvAutoSendIntervalRef.current) clearInterval(csvAutoSendIntervalRef.current)
      csvAutoSendIntervalRef.current = setInterval(() => {
        sendCsvBatch()
      }, CSV_AUTO_SEND_INTERVAL)
    } else {
      if (csvAutoSendIntervalRef.current) {
        clearInterval(csvAutoSendIntervalRef.current)
        csvAutoSendIntervalRef.current = null
      }
    }
    return () => {
      if (csvAutoSendIntervalRef.current) clearInterval(csvAutoSendIntervalRef.current)
    }
  }, [isCsvAutoSending, parsedCsvData, csvCurrentIndex])

  const toggleAutoSend = () => {
    if (parsedCsvData.length === 0) {
      toast({ title: "No CSV Data", description: "Please load a CSV file first.", variant: "destructive" })
      return
    }
    setIsCsvAutoSending(!isCsvAutoSending)
  }

  const csvProgress = parsedCsvData.length > 0 ? (csvCurrentIndex / parsedCsvData.length) * 100 : 0

  const chartData = useMemo(
      () => dashboardData?.suspiciousPercentageHistory || [],
      [dashboardData?.suspiciousPercentageHistory],
  )
  const getSuspiciousLabel = (log: NetworkFlow) =>
      log.label !== "SUSPICIOUS" ? "NORMAL" : `SUSPICIOUS (${log.markedBy || "Unknown"})`

  return (
      <div className="flex flex-col min-h-screen bg-background dark:bg-slate-950">
        <header className="sticky top-0 z-30 flex items-center justify-between h-16 px-4 border-b bg-background dark:bg-slate-900 md:px-6">
          <div className="flex items-center gap-2">
            <Network className="h-6 w-6 text-primary" />
            <h1 className="text-lg font-semibold md:text-xl">Network Flow Monitor</h1>
          </div>
          <Button onClick={handleSendSampleLogs} disabled={isSendingLogs || isLoading} size="sm">
            <UploadCloud className="mr-2 h-4 w-4" />
            {isSendingLogs ? "Sending..." : "Send Sample Flows"}
          </Button>
        </header>

        <main className="flex-1 p-4 space-y-6 sm:p-6 md:p-8">
          {/* System Status & Controls Card (existing) */}
          <Card>
            <CardHeader>
              <CardTitle>System Status & Controls</CardTitle>
              <CardDescription>Select detection method and monitor activity.</CardDescription>
            </CardHeader>
            <CardContent className="grid gap-6 md:grid-cols-3">
              <div className="space-y-4 md:col-span-1">
                <div>
                  <label htmlFor="method-select" className="text-sm font-medium mb-1 block">
                    Detection Method
                  </label>
                  <Select
                      value={activeDetectionMethod}
                      onValueChange={(value) => handleMethodChange(value as DetectionMethod)}
                      disabled={isLoading || isCsvProcessing}
                  >
                    <SelectTrigger id="method-select" className="w-full">
                      <SelectValue placeholder="Select method" />
                    </SelectTrigger>
                    <SelectContent>
                      {DETECTION_METHODS.map((method) => (
                          <SelectItem key={method} value={method}>
                            {method}
                          </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-4 md:col-span-2 grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Card
                    className={`flex flex-col justify-center items-center p-4 ${dashboardData?.isUnderAttack ? "bg-red-500/10 dark:bg-red-900/30" : "bg-green-500/10 dark:bg-green-900/30"}`}
                >
                  {dashboardData?.isUnderAttack ? (
                      <>
                        <ShieldAlert className="h-12 w-12 mb-2 text-red-500 dark:text-red-400" />
                        <p className="text-xl font-semibold text-red-600 dark:text-red-400">SYSTEM ALERT ACTIVE</p>
                        <p className="text-xs text-red-500/80 dark:text-red-400/80 mt-1">
                          High ratio of suspicious batches
                        </p>
                      </>
                  ) : (
                      <>
                        <ShieldCheck className="h-12 w-12 mb-2 text-green-600 dark:text-green-400" />
                        <p className="text-xl font-semibold text-green-700 dark:text-green-500">SYSTEM NORMAL</p>
                      </>
                  )}
                  {dashboardData && (
                      <Badge variant={dashboardData.isUnderAttack ? "destructive" : "default"} className="mt-2">
                        {dashboardData.currentSuspiciousPercentage.toFixed(2)}% Suspicious Flows (Last 5 min)
                      </Badge>
                  )}
                </Card>
                <Card className="p-4 space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Server className="h-4 w-4" />
                      <span>Total Flows (Last 5 min)</span>
                    </div>
                    <span className="font-semibold">{dashboardData?.totalLogsInWindow ?? "N/A"}</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <AlertTriangle className="h-4 w-4 text-orange-500" />
                      <span>Suspicious Flows (Last 5 min)</span>
                    </div>
                    <span className="font-semibold">{dashboardData?.suspiciousLogsInWindow ?? "N/A"}</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <BarChart3 className="h-4 w-4" />
                      <span>Active Method</span>
                    </div>
                    <span className="font-semibold">{activeDetectionMethod}</span>
                  </div>
                </Card>
              </div>
            </CardContent>
          </Card>

          {/* CSV Log Ingestion Card (New) */}
          <Card>
            <CardHeader>
              <CardTitle>CSV Log Ingestion</CardTitle>
              <CardDescription>Upload a CSV file with network flows to ingest them in batches.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center space-x-2">
                <Input
                    type="file"
                    accept=".csv"
                    onChange={handleFileChange}
                    className="cursor-pointer"
                    ref={fileInputRef}
                    disabled={isCsvProcessing || isCsvAutoSending}
                />
              </div>
              {csvFileName && (
                  <div>
                    <p className="text-sm text-muted-foreground">
                      Loaded: {csvFileName} ({parsedCsvData.length} records)
                    </p>
                    <Progress value={csvProgress} className="w-full h-2 mt-1" />
                    <p className="text-xs text-muted-foreground mt-1">
                      Processed up to line: {Math.min(csvCurrentIndex, parsedCsvData.length)} of {parsedCsvData.length}.
                      Next batch starts at: {csvCurrentIndex + 1}.
                    </p>
                  </div>
              )}
              <div className="flex flex-wrap gap-2">
                <Button
                    onClick={sendCsvBatch}
                    disabled={
                        parsedCsvData.length === 0 ||
                        csvCurrentIndex >= parsedCsvData.length ||
                        isCsvProcessing ||
                        isCsvAutoSending
                    }
                >
                  {isCsvProcessing && !isCsvAutoSending ? (
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  ) : (
                      <Send className="mr-2 h-4 w-4" />
                  )}
                  Send Next Batch ({CSV_BATCH_SIZE} lines)
                </Button>
                <Button
                    onClick={toggleAutoSend}
                    disabled={parsedCsvData.length === 0 || (isCsvProcessing && !isCsvAutoSending)}
                    variant={isCsvAutoSending ? "destructive" : "outline"}
                >
                  {isCsvAutoSending ? (
                      <>
                        <Pause className="mr-2 h-4 w-4" /> Pause Auto-Send
                      </>
                  ) : (
                      <>
                        <Play className="mr-2 h-4 w-4" /> Start Auto-Send
                      </>
                  )}
                </Button>
              </div>
              {isCsvAutoSending && (
                  <p className="text-sm text-muted-foreground">
                    Auto-sending next batch in approx. {CSV_AUTO_SEND_INTERVAL / 1000} seconds...
                  </p>
              )}
            </CardContent>
          </Card>

          {/* Suspicious Activity Trend Card (existing) */}
          <Card>
            <CardHeader>
              <CardTitle>Suspicious Activity Trend (Flow-based)</CardTitle>
              <CardDescription>
                Percentage of individual flows marked as suspicious by '{activeDetectionMethod}' over the last 5 minutes.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ChartContainer
                  config={{ percentage: { label: "Suspicious %", color: "hsl(var(--chart-1))" } }}
                  className="h-[250px] w-full"
              >
                <ResponsiveContainer>
                  <LineChart data={chartData} margin={{ top: 5, right: 20, left: -20, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} />
                    <XAxis
                        dataKey="timestamp"
                        tickFormatter={(t) => new Date(t).toLocaleTimeString([], { minute: "2-digit", second: "2-digit" })}
                        tick={{ fontSize: 12 }}
                    />
                    <YAxis domain={[0, 100]} tickFormatter={(v) => `${v}%`} tick={{ fontSize: 12 }} />
                    <ChartTooltip
                        cursor={false}
                        content={
                          <ChartTooltipContent
                              indicator="line"
                              labelFormatter={(t) => new Date(t).toLocaleTimeString()}
                              formatter={(v) => [`${(v as number).toFixed(2)}%`, "Suspicious Flows"]}
                          />
                        }
                    />
                    <Line
                        type="monotone"
                        dataKey="percentage"
                        stroke="var(--color-percentage)"
                        strokeWidth={2}
                        dot={false}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </ChartContainer>
            </CardContent>
          </Card>

          {/* Network Flow Log Card (existing) */}
          <Card>
            <CardHeader>
              <CardTitle>Network Flow Log</CardTitle>
              <CardDescription>
                Infinitely scrollable log of network flows. Showing {allLogs.length} flows.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[600px] border rounded-md">
                <Table>
                  <TableHeader className="sticky top-0 bg-muted/80 dark:bg-slate-800/80 backdrop-blur-sm z-10">
                    <TableRow>
                      <TableHead className="w-[80px]">Time</TableHead>
                      <TableHead>Source IP</TableHead>
                      <TableHead>Destination IP</TableHead>
                      <TableHead className="hidden md:table-cell">Duration (ms)</TableHead>
                      <TableHead className="hidden lg:table-cell">Fwd/Bwd Pkts</TableHead>
                      <TableHead className="hidden lg:table-cell text-right">Pkts/s</TableHead>
                      <TableHead className="w-[200px] text-right">Label</TableHead>
                      <TableHead className="w-[50px] text-center">Info</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {isLoading && allLogs.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={8} className="h-24 text-center">
                            Loading initial flows...
                          </TableCell>
                        </TableRow>
                    ) : allLogs.length > 0 ? (
                        allLogs.map((log) => (
                            <TableRow
                                key={log.id}
                                className={`cursor-pointer ${log.label === "SUSPICIOUS" ? "bg-red-500/10 dark:bg-red-900/20 hover:bg-red-500/20 dark:hover:bg-red-900/30" : "hover:bg-muted/50"}`}
                                onClick={() => handleLogRowClick(log)}
                            >
                              <TableCell className="text-xs">{formatTimestamp(log.timestamp)}</TableCell>
                              <TableCell className="font-mono text-xs">{log.sourceIp}</TableCell>
                              <TableCell className="font-mono text-xs">{log.destinationIp}</TableCell>
                              <TableCell className="hidden md:table-cell text-xs">
                                {(log["Flow Duration"] / 1000).toFixed(2)}
                              </TableCell>
                              <TableCell className="hidden lg:table-cell text-xs">
                                {log["Total Fwd Packets"]} / {log["Total Backward Packets"]}
                              </TableCell>
                              <TableCell className="hidden lg:table-cell text-xs text-right">
                                {log["Flow Packets/s"]?.toFixed(2) ?? "N/A"}
                              </TableCell>
                              <TableCell className="text-right">
                                <Badge
                                    variant={log.label === "SUSPICIOUS" ? "destructive" : "secondary"}
                                    className="text-xs whitespace-nowrap"
                                >
                                  {getSuspiciousLabel(log)}
                                </Badge>
                              </TableCell>
                              <TableCell className="text-center">
                                <Info className="h-4 w-4 text-muted-foreground inline-block" />
                              </TableCell>
                            </TableRow>
                        ))
                    ) : (
                        <TableRow>
                          <TableCell colSpan={8} className="h-24 text-center">
                            No flows to display.
                          </TableCell>
                        </TableRow>
                    )}
                    <TableRow>
                      <TableCell colSpan={8} className="h-12 text-center" ref={loaderRef}>
                        {isFetchingMore ? (
                            <Loader2 className="mx-auto h-6 w-6 animate-spin text-muted-foreground" />
                        ) : !hasMoreLogs && allLogs.length > 0 ? (
                            <span className="text-muted-foreground">End of logs</span>
                        ) : null}
                      </TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </ScrollArea>
            </CardContent>
          </Card>
        </main>
        <LogDetailModal log={selectedLog} isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} />
      </div>
  )
}
